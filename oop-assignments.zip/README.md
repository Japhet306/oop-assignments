# OOP Assignments 📘

## Activity 1: Smartphone Class
- Created a `Smartphone` class with attributes and methods
- Added `GamingPhone` subclass to demonstrate inheritance and encapsulation

## Activity 2: Polymorphism Challenge
- Created `Vehicle` base class
- Subclasses (`Car`, `Plane`, `Boat`) each define their own `move()` method
