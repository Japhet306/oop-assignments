class Smartphone:
    def __init__(self, brand, model, storage):
        self.brand = brand
        self.model = model
        self.storage = storage

    def call(self, number):
        return f"Calling {number} from {self.model}..."

    def info(self):
        return f"{self.brand} {self.model} with {self.storage}GB storage."

# Inheritance example
class GamingPhone(Smartphone):
    def __init__(self, brand, model, storage, gpu_power):
        super().__init__(brand, model, storage)
        self.gpu_power = gpu_power

    def play_game(self, game):
        return f"Playing {game} with {self.gpu_power} GPU on {self.model}!"
